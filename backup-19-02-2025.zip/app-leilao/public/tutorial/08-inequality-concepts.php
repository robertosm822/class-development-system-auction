<?php

echo (0 != false). PHP_EOL; // return false
echo ("123" != 123). PHP_EOL; // return false
echo ("one" != 1). PHP_EOL; // return true
echo (123.0 != 123). PHP_EOL; // return false
