<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout-front','data' => ['title' => 'Gerenciar Produtos']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout-front'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Gerenciar Produtos']); ?>

    <!--============= BreadCamps Section Starts Here =============-->
    <div class="hero-section style-2 pb-lg-400">
        <div class="container">
            <ul class="breadcrumb">
                <li>
                    <a href="<?php echo e(url('/')); ?>">Home</a>
                </li>
                <li>
                    <a href="#0">Admin</a>
                </li>
                <li>
                    <span>Gerenciar Produtos</span>
                </li>
            </ul>
        </div>
        <div class="bg_img hero-bg bottom_center" data-background="<?php echo e(asset('assets/images/banner/hero-bg.png')); ?>"></div>
    </div>
    <!--============= BreadCamps Section Ends Here =============-->


    <!--============= Dashboard Section Starts Here =============-->
    <section class="dashboard-section padding-bottom mt--240 mt-lg--325 pos-rel">
        <div class="container">
            <div class="row justify-content-center">

            <?php echo $__env->make('admin.admin-left-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!--INICIO DO CONTEUDO DA TELA -->
                <div class="dashboard-widget">
                    <h5 class="title mb-10">Produtos Anunciados</h5>
                    <div class="dashboard-purchasing-tabs">
                        
                        <div class="tab-content">
                            <div class="tab-pane show active fade" id="current">
                                <table class="purchasing-table">
                                    <thead>
                                        <!--
                                        'title',
                                        'current_price',
                                        'product_color',
                                        'date_expiration',
                                        'status'
                                        -->
                                        <th class="space-table-left space-table-top">Título</th>
                                        <th class="space-table-left space-table-top">R$ Inicial</th>
                                        <th class="space-table-left space-table-top">Cor</th>
                                        <!-- <th class="space-table-left space-table-top">Data Expiração</th> -->
                                        <th class="space-table-left space-table-top">Status</th>
                                        <th class="space-table-left space-table-top">Ações</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td data-purchase="item" class="space-table-left"><?php echo e($product->title); ?></td>
                                            <td data-purchase="bid price" class="space-table-left">R$ <?php echo e($product->current_price); ?></td>
                                            <td data-purchase="highest bid" class="space-table-left"><?php echo e($product->product_color); ?></td>
                                           <!-- <td data-purchase="lowest bid" class="space-table-left"><?php echo e($product->date_expiration); ?></td> -->
                                            <td data-purchase="expires" class="space-table-left"><?php echo e(($product->status === "active")? "ATIVO" : "INATIVO"); ?></td>
                                            <td data-purchase="lowest bid" class="space-table-left">
                                                <a href="#editar" title="Editar" onclick="editProduct('<?php echo e($product->id); ?>')">
                                                    <i class="small material-icons small-blue">edit_chart</i>
                                                </a> | 
                                                <a href="#excluir" title="Excluir" onclick="delProductConfirm('<?php echo e($product->id); ?>')">
                                                    <i class="small material-icons small-red">delete_chart</i>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                     
                                    </tbody>
                                </table>
                            </div>
                            <!--
                            <div class="tab-pane show fade" id="pending">
                                <table class="purchasing-table">
                                    <thead>
                                        <th>Item</th>
                                        <th>Bid Price</th>
                                        <th>Highest Bid</th>
                                        <th>Lowest Bid</th>
                                        <th>Expires</th>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td data-purchase="item">2018 Hyundai Sonata</td>
                                            <td data-purchase="bid price">$1,775.00</td>
                                            <td data-purchase="highest bid">$1,775.00</td>
                                            <td data-purchase="lowest bid">$1,400.00</td>
                                            <td data-purchase="expires">7/2/2021</td>
                                        </tr>
                                        <tr>
                                            <td data-purchase="item">2018 Hyundai Sonata</td>
                                            <td data-purchase="bid price">$1,775.00</td>
                                            <td data-purchase="highest bid">$1,775.00</td>
                                            <td data-purchase="lowest bid">$1,400.00</td>
                                            <td data-purchase="expires">7/2/2021</td>
                                        </tr>
                                        <tr>
                                            <td data-purchase="item">2018 Hyundai Sonata</td>
                                            <td data-purchase="bid price">$1,775.00</td>
                                            <td data-purchase="highest bid">$1,775.00</td>
                                            <td data-purchase="lowest bid">$1,400.00</td>
                                            <td data-purchase="expires">7/2/2021</td>
                                        </tr>
                                        <tr>
                                            <td data-purchase="item">2018 Hyundai Sonata</td>
                                            <td data-purchase="bid price">$1,775.00</td>
                                            <td data-purchase="highest bid">$1,775.00</td>
                                            <td data-purchase="lowest bid">$1,400.00</td>
                                            <td data-purchase="expires">7/2/2021</td>
                                        </tr>
                                        <tr>
                                            <td data-purchase="item">2018 Hyundai Sonata</td>
                                            <td data-purchase="bid price">$1,775.00</td>
                                            <td data-purchase="highest bid">$1,775.00</td>
                                            <td data-purchase="lowest bid">$1,400.00</td>
                                            <td data-purchase="expires">7/2/2021</td>
                                        </tr>
                                        <tr>
                                            <td data-purchase="item">2018 Hyundai Sonata</td>
                                            <td data-purchase="bid price">$1,775.00</td>
                                            <td data-purchase="highest bid">$1,775.00</td>
                                            <td data-purchase="lowest bid">$1,400.00</td>
                                            <td data-purchase="expires">7/2/2021</td>
                                        </tr>
                                        <tr>
                                            <td data-purchase="item">2018 Hyundai Sonata</td>
                                            <td data-purchase="bid price">$1,775.00</td>
                                            <td data-purchase="highest bid">$1,775.00</td>
                                            <td data-purchase="lowest bid">$1,400.00</td>
                                            <td data-purchase="expires">7/2/2021</td>
                                        </tr>
                                        <tr>
                                            <td data-purchase="item">2018 Hyundai Sonata</td>
                                            <td data-purchase="bid price">$1,775.00</td>
                                            <td data-purchase="highest bid">$1,775.00</td>
                                            <td data-purchase="lowest bid">$1,400.00</td>
                                            <td data-purchase="expires">7/2/2021</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="tab-pane show fade" id="history">
                                <table class="purchasing-table">
                                    <thead>
                                        <th>Item</th>
                                        <th>Bid Price</th>
                                        <th>Highest Bid</th>
                                        <th>Lowest Bid</th>
                                        <th>Expires</th>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td data-purchase="item">2018 Hyundai Sonata</td>
                                            <td data-purchase="bid price">$1,775.00</td>
                                            <td data-purchase="highest bid">$1,775.00</td>
                                            <td data-purchase="lowest bid">$1,400.00</td>
                                            <td data-purchase="expires">7/2/2021</td>
                                        </tr>
                                        <tr>
                                            <td data-purchase="item">2018 Hyundai Sonata</td>
                                            <td data-purchase="bid price">$1,775.00</td>
                                            <td data-purchase="highest bid">$1,775.00</td>
                                            <td data-purchase="lowest bid">$1,400.00</td>
                                            <td data-purchase="expires">7/2/2021</td>
                                        </tr>
                                        <tr>
                                            <td data-purchase="item">2018 Hyundai Sonata</td>
                                            <td data-purchase="bid price">$1,775.00</td>
                                            <td data-purchase="highest bid">$1,775.00</td>
                                            <td data-purchase="lowest bid">$1,400.00</td>
                                            <td data-purchase="expires">7/2/2021</td>
                                        </tr>
                                        <tr>
                                            <td data-purchase="item">2018 Hyundai Sonata</td>
                                            <td data-purchase="bid price">$1,775.00</td>
                                            <td data-purchase="highest bid">$1,775.00</td>
                                            <td data-purchase="lowest bid">$1,400.00</td>
                                            <td data-purchase="expires">7/2/2021</td>
                                        </tr>
                                        <tr>
                                            <td data-purchase="item">2018 Hyundai Sonata</td>
                                            <td data-purchase="bid price">$1,775.00</td>
                                            <td data-purchase="highest bid">$1,775.00</td>
                                            <td data-purchase="lowest bid">$1,400.00</td>
                                            <td data-purchase="expires">7/2/2021</td>
                                        </tr>
                                        <tr>
                                            <td data-purchase="item">2018 Hyundai Sonata</td>
                                            <td data-purchase="bid price">$1,775.00</td>
                                            <td data-purchase="highest bid">$1,775.00</td>
                                            <td data-purchase="lowest bid">$1,400.00</td>
                                            <td data-purchase="expires">7/2/2021</td>
                                        </tr>
                                        <tr>
                                            <td data-purchase="item">2018 Hyundai Sonata</td>
                                            <td data-purchase="bid price">$1,775.00</td>
                                            <td data-purchase="highest bid">$1,775.00</td>
                                            <td data-purchase="lowest bid">$1,400.00</td>
                                            <td data-purchase="expires">7/2/2021</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            -->
                        </div>
                    </div>
                </div>
                <!--FIM DO CONTEUDO DA TELA -->

            </div>
        </div>
        </div>
    </section>
    <!--============= Dashboard Section Ends Here =============-->
    <script>
        function delProductConfirm(id){
            console.log(`Deseja realmente apagar o produto ${id}?`);
        }
        function editProduct(id){
            console.log("Editando ...");
        }
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH /app/resources/views/admin/produtos-gerenciar.blade.php ENDPATH**/ ?>