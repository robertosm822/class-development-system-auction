<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout-front','data' => ['title' => 'Dashboard']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout-front'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Dashboard']); ?>
<style>
    .modal-backdrop.fade.show{
        z-index: 100;
    }
    .modal-title{
        font-size: 18px;
        float: left !important;
    }
    button.close{

        float: right;
        width: 50px;
        padding-right: 38px;
        margin-bottom: -9px;

    }
</style>
<div class="cart-sidebar-area">

<div class="top-content">
        <a href="index.html" class="logo">
            <img src="<?php echo e(asset('assets/images/logo/logo2.png')); ?>" alt="logo">
        </a>
        <span class="side-sidebar-close-btn"><i class="fas fa-times"></i></span>
    </div>
    <div class="bottom-content">
        <div class="cart-products">
            <h4 class="title">Shopping cart</h4>
            <div class="single-product-item">
                <div class="thumb">
                    <a href="#0"><img src="<?php echo e(asset('assets/images/shop/shop01.jpg')); ?>" alt="shop"></a>
                </div>
                <div class="content">
                    <h4 class="title"><a href="#0">Color Pencil</a></h4>
                    <div class="price"><span class="pprice">$80.00</span> <del class="dprice">$120.00</del></div>
                    <a href="#" class="remove-cart">Remove</a>
                </div>
            </div>
            <div class="single-product-item">
                <div class="thumb">
                    <a href="#0"><img src="<?php echo e(asset('assets/images/shop/shop02.jpg')); ?>" alt="shop"></a>
                </div>
                <div class="content">
                    <h4 class="title"><a href="#0">Water Pot</a></h4>
                    <div class="price"><span class="pprice">$80.00</span> <del class="dprice">$120.00</del></div>
                    <a href="#" class="remove-cart">Remove</a>
                </div>
            </div>
            <div class="single-product-item">
                <div class="thumb">
                    <a href="#0"><img src="<?php echo e(asset('assets/images/shop/shop03.jpg')); ?>" alt="shop"></a>
                </div>
                <div class="content">
                    <h4 class="title"><a href="#0">Art Paper</a></h4>
                    <div class="price"><span class="pprice">$80.00</span> <del class="dprice">$120.00</del></div>
                    <a href="#" class="remove-cart">Remove</a>
                </div>
            </div>
            <div class="single-product-item">
                <div class="thumb">
                    <a href="#0"><img src="<?php echo e(asset('assets/images/shop/shop04.jpg')); ?>" alt="shop"></a>
                </div>
                <div class="content">
                    <h4 class="title"><a href="#0">Stop Watch</a></h4>
                    <div class="price"><span class="pprice">$80.00</span> <del class="dprice">$120.00</del></div>
                    <a href="#" class="remove-cart">Remove</a>
                </div>
            </div>
            <div class="single-product-item">
                <div class="thumb">
                    <a href="#0"><img src="<?php echo e(asset('assets/images/shop/shop05.jpg')); ?>" alt="shop"></a>
                </div>
                <div class="content">
                    <h4 class="title"><a href="#0">Comics Book</a></h4>
                    <div class="price"><span class="pprice">$80.00</span> <del class="dprice">$120.00</del></div>
                    <a href="#" class="remove-cart">Remove</a>
                </div>
            </div>
            <div class="btn-wrapper text-center">
                <a href="#0" class="custom-button"><span>Checkout</span></a>
            </div>
        </div>
    </div>
</div>
<!--============= Cart Section Ends Here =============-->


<!--============= Hero Section Starts Here =============-->
<div class="hero-section style-2">
    <div class="container">
        <ul class="breadcrumb">
            <li>
                <a href="./index.php">Home</a>
            </li>
            <li>
                <a href="#0">Minha Conta</a>
            </li>
            <li>
                <span>Perfil</span>
            </li>
        </ul>
    </div>
    <div class="bg_img hero-bg bottom_center" data-background="<?php echo e(asset('assets/images/banner/hero-bg.png')); ?>"></div>
</div>
<!--============= Hero Section Ends Here =============-->
<!--============= Dashboard Section Starts Here =============-->

    <section class="dashboard-section padding-bottom mt--240 mt-lg--440 pos-rel">
        <div class="container">
            <div class="row justify-content-center">

            <?php echo $__env->make('admin.admin-left-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="col-lg-8">
                    <div class="row">
                        <div class="col-12">
                            <?php if(Session::get('success') ): ?>
                                <div class="alert alert-success">
                                    <?php echo e(Session::get('success')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(Session::get('errorUpdate')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(Session::get('errorUpdate')); ?>

                                </div>
                            <?php endif; ?>
                            <div class="dash-pro-item mb-30 dashboard-widget">
                                <div class="header">
                                    
                                    <h4 class="title">Dados Pessoais</h4>
                                    <span class="edit"><i data-toggle="modal" data-target="#modalPersonalDetails" class="flaticon-edit"></i> Editar</span>
                                </div>
                                <ul class="dash-pro-body">
                                    <li>
                                        <div class="info-name">Nome</div>
                                        <div class="info-value"><?php echo e(Auth::user()->name); ?></div>
                                    </li>
                                    <li>
                                        <div class="info-name">E-mail</div>
                                        <div class="info-value"><?php echo e(Auth::user()->email); ?></div>
                                    </li>
                                    <!--
                                    <li>
                                        <div class="info-name">Date of Birth</div>
                                        <div class="info-value">...</div>
                                    </li>
                                    -->
                                    <li>
                                        <div class="info-name">Endereço</div>
                                        <div class="info-value">
                                        <?php $__currentLoopData = $address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          Rua: <?php echo e($value->street); ?>, Número: <?php echo e($value->number); ?><br />
                                          <?php echo e($value->district); ?> - <?php echo e($value->city); ?> / <?php echo e($value->state); ?> <br />
                                          CEP: <?php echo e($value->zip_code); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            
                        </div>
                        <!--
                        <div class="col-12">
                            <div class="dash-pro-item mb-30 dashboard-widget">
                                <div class="header">
                                    <h4 class="title">Account Settings</h4>
                                    <span class="edit"><i class="flaticon-edit"></i> Editar</span>
                                </div>
                                <ul class="dash-pro-body">

                                    <li>
                                        <div class="info-name">Time Zone</div>
                                        <div class="info-value">(GMT-06:00) Central America</div>
                                    </li>
                                    <li>
                                        <div class="info-name">Status</div>
                                        <div class="info-value"><i class="flaticon-check text-success"></i> Active</div>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="dash-pro-item mb-30 dashboard-widget">
                                <div class="header">
                                    <h4 class="title">Email Address</h4>
                                    <span class="edit"><i class="flaticon-edit"></i> Editar</span>
                                </div>
                                <ul class="dash-pro-body">
                                    <li>
                                        <div class="info-name">Email</div>
                                        <div class="info-value"><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="3f5e535d5a4d4b0c0b067f58525e5653115c5052">[email&#160;protected]</a></div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        -->
                        <div class="col-12">
                            <div class="dash-pro-item mb-30 dashboard-widget">
                                <div class="header">
                                    <h4 class="title">Telefone</h4>
                                    <span class="edit"><i class="flaticon-edit" data-toggle="modal" data-target="#modalPersonalPhone"></i> Editar</span>
                                </div>
                                <ul class="dash-pro-body">
                                    <li>
                                        <div class="info-name">Celular</div>
                                        <div class="info-value">
                                            <?php echo e((isset($actor['phone']))? $actor['phone'] : ''); ?>

                                            <?php echo e((isset($seller['phone']))? $seller['phone'] : ''); ?>

                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="dash-pro-item dashboard-widget">
                                <div class="header">
                                    <h4 class="title">Segurança</h4>
                                    <span class="edit"><i class="flaticon-edit" data-toggle="modal" data-target="#modalPersonalPassword"></i> Editar</span>
                                </div>
                                <ul class="dash-pro-body">
                                    <li>
                                        <div class="info-name">Senha</div>
                                        <div class="info-value">xxxxxxxxxxxxxxxx</div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
</div>
<!--============= Dashboard Section Ends Here =============-->
<!-- modalPersonalDetails -->
<div id="modalPersonalDetails" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
        <div class="modal-header">
        <h4 class="modal-title">Editar Dados Pessoais</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            
        </div>
        <div class="modal-body">
            <?php if(Session::get('success') ): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('success')); ?>

                </div>
            <?php endif; ?>
            <form class="form-horizontal" method="post" action="<?php echo e(route('updateAddress')); ?>">
                <?php echo csrf_field(); ?>    
                <div class="form-group mb-30">
                    <label for="Endereco">Endereço:</label>
                </div>
                <div class="form-group mb-30">
                    <label for="cep"></label>
                    <input type="hidden" name="id" value="<?php echo e((isset($address[0]['id']))? $address[0]['id'] : ''); ?>">
                    <input type="text" id="cep" name="zip_code" value="<?php echo e((isset($address[0]['zip_code']))? $address[0]['zip_code'] : ''); ?>" placeholder="CEP" required>
                </div>
                <div class="form-group mb-30">
                    <label for="logradouro"></label>
                    <input type="text" id="logradouro" name="street" value="<?php echo e((isset($address[0]['street']))? $address[0]['street'] : ''); ?>" placeholder="Endereço" required>
                </div>
                <div class="form-group mb-30">
                    <label for="Numero"></label>
                    <input type="text" id="numero" name="number" value="<?php echo e((isset($address[0]['number']))? $address[0]['number'] : ''); ?>" placeholder="Número" required>
                </div>
                <div class="form-group mb-30">
                    <label for="bairro"></label>
                    <input type="text" id="bairro" name="district" value="<?php echo e((isset($address[0]['district']))? $address[0]['district'] : ''); ?>" placeholder="Bairro" required>
                </div>
                <div class="form-group mb-30">
                    <label for="cidade"></label>
                    <input type="text" id="cidade" name="city" value="<?php echo e((isset($address[0]['city']))? $address[0]['city'] : ''); ?>" placeholder="Cidade" required>
                </div>
                <div class="form-group mb-30">
                    <label for="estado"></label>
                    <input type="text" id="estado" name="state" value="<?php echo e((isset($address[0]['state']))? $address[0]['state'] : ''); ?>" placeholder="Estado" required>
                </div>
                <div class="form-group">        
                    <div class="col-sm-offset-2 col-sm-10">
                        <button type="submit" class="btn btn-success">ATUALIZAR</button>
                    </div>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            
        </div>
        </div>

    </div>
</div>

<!-- modalPersonalPhone -->
<div id="modalPersonalPhone" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
        <div class="modal-header">
        <h4 class="modal-title">Editar Telefone</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            
        </div>
        <div class="modal-body">
            <?php if(Session::get('success') ): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('success')); ?>

                </div>
            <?php endif; ?>
            <?php if(Auth::user()->user_type_login === 'anunciante'): ?>
                <form class="form-horizontal" method="post" action="<?php echo e(route('update-phone', $seller['id'])); ?>">
                    <?php echo csrf_field(); ?>    
                    <div class="form-group mb-30">
                        <label for="Endereco">Digite um número de telefone:</label>
                    </div>
                    <div class="form-group mb-30">
                        <label for="phone"></label>
                        <input type="hidden" name="id" value="">
                        <input type="text" id="phone" name="phone" value="<?php echo e($seller['phone']); ?>" placeholder="Número" required>
                    </div>
                    
                    <div class="form-group">        
                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="submit" class="btn btn-success">ATUALIZAR</button>
                        </div>
                    </div>
                </form>
            <?php else: ?> 
                <form class="form-horizontal" method="post" action="<?php echo e(route('update-phone', $actor['id'])); ?>">
                    <?php echo csrf_field(); ?>    
                    <div class="form-group mb-30">
                        <label for="Endereco">Digite um número de telefone:</label>
                    </div>
                    <div class="form-group mb-30">
                        <label for="phone"></label>
                        <input type="hidden" name="id" value="">
                        <input type="text" id="phone" name="phone" value="<?php echo e($actor['phone']); ?>" placeholder="Número" required>
                    </div>
                    
                    <div class="form-group">        
                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="submit" class="btn btn-success">ATUALIZAR</button>
                        </div>
                    </div>
                </form>
            <?php endif; ?>
        </div>
        <div class="modal-footer">
            
        </div>
        </div>

    </div>
</div>

<!-- modalPersonalPassword -->
<div id="modalPersonalPassword" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
        <div class="modal-header">
        <h4 class="modal-title">Editar Senha</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            
        </div>
        <div class="modal-body">
            <?php if(Session::get('success') ): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('success')); ?>

                </div>
            <?php endif; ?>
           
            <form class="form-horizontal" method="post" action="<?php echo e(route('update-password')); ?>">
                <?php echo csrf_field(); ?>    
                <div class="form-group mb-30">
                    <label for="Endereco">Senha:</label>
                </div>
                <div class="form-group mb-30">
                    <label for="password"></label>
                    <?php echo e(method_field('PUT')); ?>

                    <input type="password" id="password" name="password" required>
                </div>
                
                <div class="form-group">        
                    <div class="col-sm-offset-2 col-sm-10">
                        <button type="submit" class="btn btn-success">ATUALIZAR</button>
                    </div>
                </div>
            </form>
            
        </div>
        <div class="modal-footer">
            
        </div>
        </div>

    </div>
</div>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH /app/resources/views/admin/perfil.blade.php ENDPATH**/ ?>