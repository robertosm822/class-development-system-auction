<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout-front','data' => ['title' => 'Cadastrar Produto']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout-front'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Cadastrar Produto']); ?>
<style>
    .modal-backdrop.fade.show{
        z-index: 100;
    }
    .modal-title{
        font-size: 18px;
        float: left !important;
    }
    button.close{

        float: right;
        width: 50px;
        padding-right: 38px;
        margin-bottom: -9px;

    }
    .filenames-active{
        border-radius: 9px;border: 1px solid silver;padding: 10px;
    }
    .h4-arquivos {
        font-size: 16px;
    }
</style>
<div class="cart-sidebar-area">

<div class="top-content">
        <a href="index.html" class="logo">
            <img src="<?php echo e(asset('assets/images/logo/logo2.png')); ?>" alt="logo">
        </a>
        <span class="side-sidebar-close-btn"><i class="fas fa-times"></i></span>
    </div>
    <div class="bottom-content">
        <div class="cart-products">
            <h4 class="title">Shopping cart</h4>
            <div class="single-product-item">
                <div class="thumb">
                    <a href="#0"><img src="<?php echo e(asset('assets/images/shop/shop01.jpg')); ?>" alt="shop"></a>
                </div>
                <div class="content">
                    <h4 class="title"><a href="#0">Color Pencil</a></h4>
                    <div class="price"><span class="pprice">$80.00</span> <del class="dprice">$120.00</del></div>
                    <a href="#" class="remove-cart">Remove</a>
                </div>
            </div>
            <div class="single-product-item">
                <div class="thumb">
                    <a href="#0"><img src="<?php echo e(asset('assets/images/shop/shop02.jpg')); ?>" alt="shop"></a>
                </div>
                <div class="content">
                    <h4 class="title"><a href="#0">Water Pot</a></h4>
                    <div class="price"><span class="pprice">$80.00</span> <del class="dprice">$120.00</del></div>
                    <a href="#" class="remove-cart">Remove</a>
                </div>
            </div>
            <div class="single-product-item">
                <div class="thumb">
                    <a href="#0"><img src="<?php echo e(asset('assets/images/shop/shop03.jpg')); ?>" alt="shop"></a>
                </div>
                <div class="content">
                    <h4 class="title"><a href="#0">Art Paper</a></h4>
                    <div class="price"><span class="pprice">$80.00</span> <del class="dprice">$120.00</del></div>
                    <a href="#" class="remove-cart">Remove</a>
                </div>
            </div>
            <div class="single-product-item">
                <div class="thumb">
                    <a href="#0"><img src="<?php echo e(asset('assets/images/shop/shop04.jpg')); ?>" alt="shop"></a>
                </div>
                <div class="content">
                    <h4 class="title"><a href="#0">Stop Watch</a></h4>
                    <div class="price"><span class="pprice">$80.00</span> <del class="dprice">$120.00</del></div>
                    <a href="#" class="remove-cart">Remove</a>
                </div>
            </div>
            <div class="single-product-item">
                <div class="thumb">
                    <a href="#0"><img src="<?php echo e(asset('assets/images/shop/shop05.jpg')); ?>" alt="shop"></a>
                </div>
                <div class="content">
                    <h4 class="title"><a href="#0">Comics Book</a></h4>
                    <div class="price"><span class="pprice">$80.00</span> <del class="dprice">$120.00</del></div>
                    <a href="#" class="remove-cart">Remove</a>
                </div>
            </div>
            <div class="btn-wrapper text-center">
                <a href="#0" class="custom-button"><span>Checkout</span></a>
            </div>
        </div>
    </div>
</div>
<!--============= Cart Section Ends Here =============-->


<!--============= Hero Section Starts Here =============-->
<div class="hero-section style-2">
    <div class="container">
        <ul class="breadcrumb">
            <li>
                <a href="./index.php">Home</a>
            </li>
            <li>
                <a href="#0">Produtos | Anúcios</a>
            </li>
            <li>
                <span>Cadastrar</span>
            </li>
        </ul>
    </div>
    <div class="bg_img hero-bg bottom_center" data-background="<?php echo e(asset('assets/images/banner/hero-bg.png')); ?>"></div>
</div>
<!--============= Hero Section Ends Here =============-->
<!--============= Dashboard Section Starts Here =============-->

    <section class="dashboard-section padding-bottom mt--240 mt-lg--440 pos-rel">
        <div class="container">
            <div class="row justify-content-center">

            <?php echo $__env->make('admin.admin-left-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="col-lg-8">
                    <div class="row">
                        <div class="col-12">
                            <?php if(Session::get('success') ): ?>
                                <div class="alert alert-success">
                                    <?php echo e(Session::get('success')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(Session::get('errorUpdate')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(Session::get('errorUpdate')); ?>

                                </div>
                            <?php endif; ?>
                            
                                
                            <div class="dash-pro-item mb-30 dashboard-widget">
                                <div class="header">
                                    
                                    <h4 class="title">Cadastrar Imagens:</h4>
                                    <!-- <span class="edit"><i data-toggle="modal" data-target="#modalPersonalDetails" class="flaticon-edit"></i> Editar</span> -->
                                </div>
                                <ul class="dash-pro-body">
                                    <li>
                                        <div class="info-name">Escolha</div>
                                        <div class="info-value">
                                            <input type="file" name="files[]"  form="formAnnoucement"  id="inputFile" multiple  class="form-control <?php $__errorArgs = ['files'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <?php $__errorArgs = ['files'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="info-value" style="width: 100%;">
                                            <div class="filenames"></div>
                                        </div>
                                    </li>
                                    
                                    
                                </ul>
                            </div>

                            
                        </div>
                        <form action="<?php echo e(route('upload.files')); ?>" method="post" enctype="multipart/form-data" style="width: 100%;" id="formAnnoucement">
                            <?php echo csrf_field(); ?>
                            <div class="col-12">
                                <div class="dash-pro-item mb-30 dashboard-widget">
                                    <div class="header">
                                        <h4 class="title">Categoria</h4>
                                        <!-- <span class="edit"><i class="flaticon-edit" data-toggle="modal" data-target="#modalPersonalPhone"></i> Editar</span> -->
                                    </div>
                                    <ul class="dash-pro-body">
                                        <li>
                                            <div class="info-name">Escolha</div>
                                            <div class="info-value">
                                                <select name="category_id" id="category_id">
                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </li>
                                    </ul>
                                    <input type="hidden" name="announcement_id" value="">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="dash-pro-item dashboard-widget">
                                    <div class="header">
                                        <h4 class="title">Informações do Produto | Ativo</h4>
                                        <!-- <span class="edit"><i class="flaticon-edit" data-toggle="modal" data-target="#modalPersonalPassword"></i> Editar</span> -->
                                    </div>
                                    <ul class="dash-pro-body">
                                        <li>
                                            <div class="info-name">Título:</div>
                                            <div class="info-value">
                                                <input class="form-control" type="text" name="title" id="title" required>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="info-name">Descrição</div>
                                            <div class="info-value">
                                                <textarea class="form-control" name="description" id="description" cols="30" rows="10"></textarea>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="info-name">Preço Inicial</div>
                                            <div class="info-value">
                                            <input class="form-control" type="number" name="current_price" id="current_price" required>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="info-name">Incremento</div>
                                            <div class="info-value">
                                                <input type="number" name="product_bid_increment" id="product_bid_increment" value="100.00" placeholder="100.00" required>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="info-name">Inicia em</div>
                                            <div class="info-value">
                                                <input type="text" name="date_started" id="date_started" placeholder="dd/mm/YYYY" required>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="info-name">Expira em</div>
                                            <div class="info-value">
                                                <input type="text" name="date_expiration" id="date_expiration" placeholder="dd/mm/YYYY" required>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="info-name">Status</div>
                                            <div class="info-value">
                                                <select name="status" id="status">
                                                    <option value="active">Ativo</option>
                                                    <option value="inactive">Inativo | Desabilitado</option>
                                                </select>
                                            </div>
                                        </li>
                                        <li>
                                           
                                                <button class="btn-info" style="margin-top: 20px;">CADASTRAR</button>
                                            
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
</div>
<!--============= Dashboard Section Ends Here =============-->
<script>

//recurso visual para mostrar quais arquivos foram selecionados
setTimeout(() => {
    $('input[name="files[]"]').change(function(){
        $('.filenames').html('<br><h4 class="h4-arquivos">Arquivos selecionados:</h4><hr>');
        for(var i = 0 ; i < this.files.length ; i++){
            const fileName = this.files[i].name;
            console.log(fileName);
            $('.filenames').addClass('filenames-active');
            $('.filenames').append('<div class="name">' + fileName + '</div>');
        }
    });
}, 1000);
 
    
</script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH /app/resources/views/admin/cadastrar-produto.blade.php ENDPATH**/ ?>